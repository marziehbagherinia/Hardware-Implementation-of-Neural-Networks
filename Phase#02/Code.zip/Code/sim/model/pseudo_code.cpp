#include<bits/stdc++.h>
using namespace std;

long long int N_in[750][62];
long long int WH[20][62];
long long int WO[10][20];
long long int BH[20];
long long int BO[10];
int N_out[750];

int decimal_to_binary(long long int decimal)
{ 
    long long int i = 1;
    long long int sum = 0;
    long long int remainder = 1;
  
    while (decimal < 0 || decimal > 0)
    {
        remainder = decimal %2;
        sum = sum + (i * remainder);
        decimal = decimal / 2;
        i = i * 10;
    }

    return sum;
}

long long int binary_to_decimal(long long int n)
{
    long long int decimal = 0, i = 0, remainder;

    while (true)
    {
        if (n <= 1)
            break;

        remainder = n % 10;
        n /= 10;

        decimal += remainder * pow(2,i);
        ++i;
    }

    if (n == 0)
        return decimal;
    else
        return -1*decimal;
    
}

long long int convert_to_sm(long long int decimal)
{
    if (decimal <= 127 )
        return decimal;

    long long int binary = decimal_to_binary(decimal);
    return binary_to_decimal(binary);
}

void read_file(string filename)
{
	string line;
	vector <int> gettingLine;
	
	ifstream myfile(filename.c_str());

	if(myfile.is_open())
	{
		while (myfile >> line)
		{
			gettingLine.push_back(stoi(line, 0, 16));
		}
	}
	
	myfile.close();    
	   
	if (filename == "bh_sm.dat")
		for (int i = 0; i < 20; i++)
			BH[i] = convert_to_sm(gettingLine[i]);
	else if(filename == "bo_sm.dat")                
		for (int i = 0; i < 10; i++)
			BO[i] = convert_to_sm(gettingLine[i]);
	else if(filename == "wh_sm.dat")
		for (int i = 0; i < 20; i++)
			for (int j = 0; j < 62; j++)
				WH[i][j] = convert_to_sm(gettingLine[i*62 + j]);
	else if(filename == "wo_sm.dat")
		for (int i = 0; i < 10; i++)
			for (int j = 0; j < 20; j++)
				WO[i][j] = convert_to_sm(gettingLine[i*20 + j]);
	else if(filename == "test_data_sm.dat")
		for (int i = 0; i < 750; i++)
			for (int j = 0; j < 62; j++)
				N_in[i][j] = convert_to_sm(gettingLine[i*62 + j]);
	else if(filename == "test_lable_sm.dat")
		for (int i = 0; i < 750; i++)
			N_out[i] = gettingLine[i];  				                                              
											 
}

int ReLU(int H)
{
		return max(H, 0);
}

int Sat(int H)
{
		if (H > 127)
				return 127;
		return H;
}

int MAC(long long int NN_in[62])
{
		long long int H_out[20];
		long long int O_out[10];

		for (int i = 0; i < 20; i++)
		{
				H_out[i] = 0;
				
				for (int j = 0; j < 62; j++)
				{
					H_out[i] += WH[i][j]*NN_in[j];
					
				 }

				H_out[i] += (BH[i]*127);
				H_out[i] = H_out[i] >> 9;
				H_out[i] = ReLU(H_out[i]);
				H_out[i] = Sat(H_out[i]);

				cout << H_out[i] << endl; 		
		}

		cout << "Final Layer: " << endl;
		for (int i = 0; i < 10; i++)
		{
				O_out[i] = 0;
				for (int j = 0; j < 20; j++)
				{
					O_out[i] += WO[i][j]*H_out[j];
					/*if(i == 9)
					{
						cout << j << " " << H_out[j] << " " <<  WO[i][j] << " " << WO[i][j]*H_out[j] << " " << O_out[i] << endl;
					}*/
				}
				O_out[i] += (BO[i]*127);
				O_out[i] = O_out[i] >> 9;
				O_out[i] = ReLU(O_out[i]);
				O_out[i] = Sat(O_out[i]);
				
				
				cout << O_out[i] << endl;
		}
		
		long long int maximum = O_out[0];
		int maximum_index = 0;

		for (int i = 1; i < 10; ++i)
		{
			if (O_out[i] >= maximum)
			{
				maximum = O_out[i];
				maximum_index = i;
			}
		}

		return maximum_index;
}

int main()
{
		int Res[750]; 

		string WH_filename = "wh_sm.dat";
		string WO_filename = "wo_sm.dat";
		string BH_filename = "bh_sm.dat";
		string BO_filename = "bo_sm.dat";		
		string N_in_filename = "test_data_sm.dat";
		string N_out_filename = "test_lable_sm.dat";

		read_file(WH_filename);
		read_file(WO_filename);
		read_file(BH_filename);
		read_file(BO_filename);
		read_file(N_in_filename);
		read_file(N_out_filename);

		int cnt = 0;
		for (int i = 0; i < 1; i++)
		        Res[i] = MAC(N_in[i]);

/*
		for (int i = 0; i < 750; ++i)
			if (Res[i] == N_out[i])
				cnt += 1;

		cout << cnt << endl;	
		
		ofstream fout;
		
		fout.open("output.txt");

		if(fout.is_open())
		{
			fout << "Cal  &  Real " << endl;
			for (int i = 0; i < 750; ++i)
				fout << Res[i] << " " << N_out[i] << endl;
		}*/
}
